# Collected Matlab Code of Active Contour Model for Image Segmentation
Here are some matlab code of Active Contour Models, which are collected from the Internet.

Only used for research.