function Delta_h = Delta(phi, epsilon)


Delta_h=(epsilon/pi)./(epsilon^2+ phi.^2);