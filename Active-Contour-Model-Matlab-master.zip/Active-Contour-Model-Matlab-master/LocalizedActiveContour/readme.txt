Copyright (c) 2012, 
Jincheng Pang @ ECE Department, Tufts University
jinchengpang@gmail.com
All Rights Reserved, 2012                                         
How to use?
The file Demo_LAC could be run directly.